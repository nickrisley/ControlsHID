import React, { Component } from 'react';
import { connect } from 'react-redux';

class Dashboard extends Component {
  constructor(props) {
    super(props);

    // Initial state.
    this.state = {
      todo: null,
      error: false,
      data: [],
    };
  }

  componentDidMount() {
  }
  render() {
    const { data, error } = this.state;

    return (
      <div className="container py-5">
        <div className="add-todos mb-5">
          <h2 className="mb-4">Your are logedin as {this.props.user.name} </h2>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  isAuthenticated: state.Auth.isAuthenticated,
  user: state.Auth.user,
});

export default connect(mapStateToProps)(Dashboard);
