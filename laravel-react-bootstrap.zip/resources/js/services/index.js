import * as AuthService from './authService';

export default AuthService;
